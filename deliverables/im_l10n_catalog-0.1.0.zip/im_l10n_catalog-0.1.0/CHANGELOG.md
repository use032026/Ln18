# Changelog

## 0.1.0

- 从 chat-im-cs 提取 20 个真实词条、6 种语言，按 common、auth、chat、settings 归属组织。
- 消费者按语言、模块和 key 清单生成 ARB，支持专属文案覆盖及版本一致性检查。
- 保留参数 metadata 与 ICU 原文，由 Flutter gen-l10n 生成调用接口。
- 本地示例版本，未发布到远程。
