# IM 公共翻译包示例 0.1.0

这是构建时使用的私有 Dart 包。`catalog/` 统一维护翻译源，`bin/generate.dart` 根据消费者清单生成 ARB；运行时由 Flutter 官方 `gen-l10n` 生成的类提供翻译，不自建 ICU 渲染器。

包版本在 `pubspec.yaml`、`catalog/index.json` 和消费者的 `catalogVersion` 中保持一致。示例采用本地 `path` 开发依赖；正式接入可固定私有 Git tag/commit，并保留消费者的依赖锁文件。此目录没有授权公开发布翻译内容，因此使用 `publish_to: none`。

消费者目录运行：

```sh
flutter pub get
dart run im_l10n_catalog:generate l10n.bundle.json
flutter gen-l10n
```

清单示例：

```json
{
  "schemaVersion": 1,
  "catalogVersion": "0.1.0",
  "locales": ["en", "zh"],
  "templateLocale": "en",
  "modules": ["common", "chat", "settings"],
  "excludeKeys": ["commonDelete"],
  "overridesDir": "l10n_overrides",
  "outputDir": "lib/l10n",
  "outputClass": "SdkLocalizations"
}
```

- `locales` 使用资源中的规范码：`zh`、`zh_TW`、`en`、`ja`、`ko`、`vi`。本工具拒绝未知语言码，不隐式转换宿主 API 中的 `zh-CN` 等别名。
- `modules` 按模块选择；可选的 `includeKeys` 再取白名单，`excludeKeys` 排除具体词条。词条必须属于已选模块。
- `l10n_overrides/en.json` 等是 `key: text` 的 JSON 对象，覆盖层只能修改实际选中的词条，并保持占位参数不变。
- 模板语言可与包默认语言不同。生成器始终从包默认语言读取参数类型和 metadata，随后写入所选语言的 ARB。
- 输出 `l10n.yaml`、`l10n.bundle.lock.json`、`lib/l10n/arb/`。锁文件记录包版本、选择范围、覆盖词条和生成内容摘要。
- `outputDir` 是生成器独占目录；手写文件和覆盖层必须放在外面。重生成会清除该目录内旧 ARB 和旧生成 Dart，再运行 `flutter gen-l10n`。工具对未标记目录、未知文件、符号链接和越界路径直接报错，避免误删源码。
- 语言、模块、key、版本、翻译或参数签名错误在写输出之前失败。ICU 的完整语法和最终 Dart 类型检查仍交给 `flutter gen-l10n` 与 `flutter analyze`。

公共包应放在消费者的 `dev_dependencies` 中，消费者运行时只导入生成的本地化类。不要把公共 `catalog/` 声明为 Flutter assets；否则会重新将完整资源带入安装包。SDK 的宿主也不依赖 SDK 的开发依赖，因此 SDK 发布前必须生成并随包提供所选 Dart 本地化代码。

本例只提取一组真实词条展示组织和构建机制，不代表已经迁移 chat-im-cs 或 IMSDK 的全部语言资源。
